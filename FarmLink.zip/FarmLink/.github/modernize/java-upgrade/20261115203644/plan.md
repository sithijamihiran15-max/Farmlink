# Upgrade Plan: FarmLink (20261115203644)

- **Generated**: 2026-11-16 20:36:44
- **HEAD Branch**: N/A
- **HEAD Commit ID**: N/A

## Available Tools

**JDKs**
- JDK 27: C:\Program Files\Java\jdk-27\bin (available in local environment; non-LTS runtime)
- JDK 25: **<TO_BE_INSTALLED>** (required for the target LTS runtime; Step 1)
- JDK 21: not available (baseline will be skipped)

**Build Tools**
- Maven 3.10.0: C:\apache-maven-3.10.0\bin
- Maven Wrapper: ./mvnw (present in project root; wrapper metadata not bundled in .mvn directory)

## Guidelines

> Note: You can add any specific guidelines or constraints for the upgrade process here if needed, bullet points are preferred.

- Upgrade the Java runtime to the latest LTS version (Java 25) in auto-execution mode.
- Keep changes limited to runtime/toolchain compatibility and verified build/test requirements.
- Use the project Maven wrapper when available and set JAVA_HOME to the JDK 25 installation for validation.
- Do not broaden the change beyond the active build/runtime configuration unless verification reveals a compatibility issue.

## Options

- Working branch: appmod/java-upgrade-20261115203644
- Run tests before and after the upgrade: true

## Upgrade Goals

- Java 25

## Technology Stack

| Technology/Dependency | Current | Min Compatible Version | Why Incompatible |
| ---------------------- | ------- | ---------------------- | --------------- |
| Java | 21 | 25 | User requested latest LTS runtime upgrade |
| Spring Boot | 4.1.2 | 4.1.2 | Already compatible with modern JDKs; no framework bump required |
| Maven Wrapper | unknown | 3.9+ recommended | Build tool should be run with a JDK 25-aware toolchain; wrapper is present |
| Maven | 3.10.0 | 3.9+ recommended | Current version is compatible with Java 25; no forced upgrade needed |

## Derived Upgrades

- Java 25 target requires the project runtime and build toolchain to be executed with a JDK 25 installation.
- Spring Boot 4.1.2 already targets current Java LTS levels; no framework-level version bump is required for this runtime-only upgrade.
- Project `pom.xml` currently sets `java.version` to 21, which must be raised to 25 to satisfy the user goal.
- If the Maven wrapper or build scripts rely on an older JAVA_HOME or hard-coded JDK path, update them during execution.

## Impact Analysis

### Subsection: Dependency Changes

| File | Dependency | Current | Action | Target | Reason |
|------|-----------|---------|--------|--------|--------|
| pom.xml | java.version | 21 | upgrade | 25 | User requested latest LTS Java runtime |
| pom.xml | spring-boot-starter-parent | 4.1.2 | keep | 4.1.2 | Boot 4.1.2 is already modern and compatible with Java 25 |

### Subsection: Source Code Changes

| File | Location | Current | Required Change | Reason |
|------|----------|---------|----------------|--------|
| None identified | N/A | N/A | No direct source-level Java API changes are currently expected for this runtime-only upgrade | Boot 4.1.2 is already on the modern runtime stack |

### Subsection: Configuration Changes

| File | Property/Setting | Current | Required Change | Reason |
|------|------------------|---------|-----------------|--------|
| pom.xml | java.version | 21 | Update to 25 | Java runtime target must meet latest LTS requirement |
| build scripts / env | JAVA_HOME / JDK path | local environment may point to older JDK | Set JAVA_HOME to JDK 25 during validation | Maven and Java compilation must use the target JDK |

### Subsection: CI/CD Changes

| File | Location | Current | Required Change |
|------|----------|---------|----------------|
| None identified | N/A | N/A | No CI/CD pipeline files were found in the project root for current Java version enforcement |

### Subsection: Risks & Warnings

- **Toolchain mismatch risk**: The local environment already contains JDK 27, which is not the target LTS runtime. **Mitigation**: install JDK 25 and validate with `JAVA_HOME` pointing to the JDK 25 installation before running Maven builds.
- **Documentation drift risk**: Existing docs mention Java 21 and older compile settings, but they do not affect build behavior. **Mitigation**: update only if runtime validation reveals a mismatch or project docs are intended to reflect the new Java target.
- **Build script assumptions**: The repository includes scripts like `run.bat` / `run.sh` and a Maven wrapper that may assume a local JDK or `JAVA_HOME` configuration. **Mitigation**: verify the wrapper and boot scripts still start under the JDK 25 toolchain.

## Upgrade Steps

- Step 1: Install and verify JDK 25 toolchain
  - **Rationale**: The project is already on Java 21 in configuration but must be built and validated using the latest LTS runtime. Installing JDK 25 first establishes the required runtime before any code changes.
  - **Changes to Make**: Install JDK 25 and verify the Java home path; confirm Maven can run under the target JDK.
  - **Verification**: `java -version` and `./mvnw -version` with `JAVA_HOME` set to JDK 25; expected result is Java 25 reporting and Maven booting successfully.

- Step 2: Setup Baseline
  - **Rationale**: The project’s configured current JDK is 21, but the local machine does not provide JDK 21. The base JDK is therefore unavailable, so baseline compilation is skipped in accordance with the upgrade workflow.
  - **Changes to Make**: No source changes; record the skipped baseline and move directly to runtime upgrade validation.
  - **Verification**: Baseline command skipped because JDK 21 is not installed locally; expected result is a documented skip, not a failure.

- Step 3: Upgrade Java runtime target to 25
  - **Rationale**: This is the only project-level change required for the requested runtime upgrade. Spring Boot 4.1.2 is already modern and does not require a framework migration for Java 25.
  - **Changes to Make**: Update `pom.xml` `java.version` from 21 to 25 and ensure any explicit Java toolchain settings remain aligned with the target JDK.
  - **Verification**: `./mvnw -q clean test-compile` with `JAVA_HOME` set to JDK 25; expected result is successful compilation of main and test code.

- Step 4: Final validation and fix loop
  - **Rationale**: After the runtime change, the build must still pass its full test suite under Java 25. This captures any compatibility regressions introduced by the upgrade.
  - **Changes to Make**: Fix any Java 25 compatibility issues revealed by the build or test suite; keep edits targeted and minimal.
  - **Verification**: `./mvnw -q clean test` with `JAVA_HOME` set to JDK 25; expected result is 100% pass rate or a documented, justified blocker with a remediation attempt.
